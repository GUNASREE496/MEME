import React, { useState, useEffect, useRef } from "react";
import ReactDOM from "react-dom/client";

const MEME_TEMPLATES = {
  fry: { name: "Fry", url: "https://api.memegen.link/images/fry.png" },
  drake: { name: "Drake Hotline Bling", url: "https://api.memegen.link/images/drake.png" },
  distracted: { name: "Distracted Boyfriend", url: "https://api.memegen.link/images/distracted.png" },
  doge: { name: "Doge", url: "https://api.memegen.link/images/doge.png" },
  "disaster-girl": { name: "Disaster Girl", url: "https://api.memegen.link/images/disastergirl.png" },
  "two-buttons": { name: "Two Buttons", url: "https://api.memegen.link/images/two-buttons.png" },
  "grumpy-cat": { name: "Grumpy Cat", url: "https://api.memegen.link/images/grumpycat.png" },
  "success-kid": { name: "Success Kid", url: "https://api.memegen.link/images/success.png" }
};

function MemeApp() {
  const [topText, setTopText] = useState("GUNNA");
  const [bottomText, setBottomText] = useState("FAAAHHH.....");
  const [templateKey, setTemplateKey] = useState("fry");
  const [selectedTemplate, setSelectedTemplate] = useState("fry");
  const [imageSrc, setImageSrc] = useState("https://api.memegen.link/images/fry.png");
  const [loading, setLoading] = useState(false);

  const canvasRef = useRef(null);
  const fileInputRef = useRef(null);
  const loadedImageRef = useRef(null);

  useEffect(() => {
    setLoading(true);
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      loadedImageRef.current = img;
      setLoading(false);
      drawMeme();
    };
    img.onerror = () => setLoading(false);
    img.src = imageSrc;
  }, [imageSrc]);

  useEffect(() => {
    drawMeme();
  }, [topText, bottomText]);

  const wrapText = (ctx, text, maxWidth) => {
    const words = text.split(" ");
    const lines = [];
    let currentLine = words[0] || "";
    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const width = ctx.measureText(currentLine + " " + word).width;
      if (width < maxWidth) {
        currentLine += " " + word;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    if (currentLine) lines.push(currentLine);
    return lines;
  };

  const drawMeme = () => {
    const canvas = canvasRef.current;
    if (!canvas || !loadedImageRef.current) return;
    const ctx = canvas.getContext("2d");
    const img = loadedImageRef.current;

    const maxWidth = 700;
    const aspect = img.naturalHeight / img.naturalWidth;
    canvas.width = maxWidth;
    canvas.height = Math.round(maxWidth * aspect);

    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    const upperTop = topText.trim().toUpperCase();
    const upperBottom = bottomText.trim().toUpperCase();
    const fontSize = Math.max(28, Math.floor(canvas.width / 13));
    
    ctx.font = `900 ${fontSize}px "Impact", "Anton", sans-serif`;
    ctx.textAlign = "center";
    ctx.fillStyle = "#ffffff";
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = Math.max(4, Math.floor(fontSize / 7));
    ctx.lineJoin = "round";

    const maxTextWidth = canvas.width * 0.92;
    const lineHeight = fontSize * 1.15;

    if (upperTop) {
      const lines = wrapText(ctx, upperTop, maxTextWidth);
      ctx.textBaseline = "top";
      lines.forEach((line, i) => {
        ctx.strokeText(line, canvas.width / 2, 20 + i * lineHeight);
        ctx.fillText(line, canvas.width / 2, 20 + i * lineHeight);
      });
    }

    if (upperBottom) {
      const lines = wrapText(ctx, upperBottom, maxTextWidth);
      ctx.textBaseline = "bottom";
      lines.forEach((line, i) => {
        const y = canvas.height - 20 - (lines.length - 1 - i) * lineHeight;
        ctx.strokeText(line, canvas.width / 2, y);
        ctx.fillText(line, canvas.width / 2, y);
      });
    }
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL("image/png");
    const link = document.createElement("a");
    link.download = `${templateKey || "meme"}_${Date.now()}.png`;
    link.href = dataUrl;
    link.click();
  };

  const handleSelectChange = (e) => {
    const val = e.target.value;
    setSelectedTemplate(val);
    if (val === "custom") {
      fileInputRef.current?.click();
    } else if (MEME_TEMPLATES[val]) {
      setTemplateKey(val);
      setImageSrc(MEME_TEMPLATES[val].url);
    }
  };

  const handleKeyChange = (e) => {
    const val = e.target.value;
    setTemplateKey(val);
    const clean = val.toLowerCase().trim();
    if (MEME_TEMPLATES[clean]) {
      setSelectedTemplate(clean);
      setImageSrc(MEME_TEMPLATES[clean].url);
    } else if (clean) {
      setImageSrc(`https://api.memegen.link/images/${clean}.png`);
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (evt) => setImageSrc(evt.target.result);
      reader.readAsDataURL(file);
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <div style={styles.canvasWrapper}>
          <canvas ref={canvasRef} style={styles.canvas} />
          {loading && <div style={styles.loading}>Loading image...</div>}
        </div>

        <button type="button" style={styles.downloadBtn} onClick={handleDownload}>
          Download
        </button>

        <div style={styles.formGroup}>
          <label style={styles.label}>Top text</label>
          <input
            type="text"
            value={topText}
            placeholder="Enter top text..."
            style={styles.input}
            onChange={(e) => setTopText(e.target.value)}
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Bottom text</label>
          <input
            type="text"
            value={bottomText}
            placeholder="Enter bottom text..."
            style={styles.input}
            onChange={(e) => setBottomText(e.target.value)}
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Meme template</label>
          <input
            type="text"
            value={templateKey}
            placeholder="e.g. fry, doge, drake..."
            style={styles.input}
            onChange={handleKeyChange}
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Select template</label>
          <select
            value={selectedTemplate}
            style={styles.select}
            onChange={handleSelectChange}
          >
            <option value="fry">Fry</option>
            <option value="drake">Drake Hotline Bling</option>
            <option value="distracted">Distracted Boyfriend</option>
            <option value="doge">Doge</option>
            <option value="disaster-girl">Disaster Girl</option>
            <option value="two-buttons">Two Buttons</option>
            <option value="grumpy-cat">Grumpy Cat</option>
            <option value="success-kid">Success Kid</option>
            <option value="custom">Upload Custom Image...</option>
          </select>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            style={{ display: "none" }}
            onChange={handleFileUpload}
          />
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: "100vh",
    backgroundColor: "#272a30",
    display: "flex",
    justifyContent: "center",
    alignItems: "flex-start",
    padding: "24px 16px",
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    boxSizing: "border-box"
  },
  card: {
    width: "100%",
    maxWidth: "480px",
    backgroundColor: "#383d46",
    borderRadius: "8px",
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    gap: "16px",
    boxShadow: "0 10px 30px rgba(0,0,0,0.4)",
    border: "1px solid rgba(255,255,255,0.08)",
    boxSizing: "border-box"
  },
  canvasWrapper: {
    position: "relative",
    width: "100%",
    aspectRatio: "4 / 3.3",
    backgroundColor: "#1a1c20",
    borderRadius: "4px",
    overflow: "hidden",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    border: "1px solid rgba(0,0,0,0.3)"
  },
  canvas: {
    width: "100%",
    height: "100%",
    objectFit: "contain",
    display: "block"
  },
  loading: {
    position: "absolute",
    inset: 0,
    backgroundColor: "rgba(26,28,32,0.85)",
    color: "#cbd5e1",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "14px",
    fontWeight: "500"
  },
  downloadBtn: {
    width: "100%",
    padding: "12px 20px",
    backgroundColor: "#2b3038",
    color: "#ffffff",
    border: "1.5px solid #d1d5db",
    borderRadius: "4px",
    fontFamily: "Impact, Anton, sans-serif",
    fontSize: "20px",
    letterSpacing: "1px",
    textTransform: "capitalize",
    cursor: "pointer",
    boxSizing: "border-box"
  },
  formGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "6px"
  },
  label: {
    fontSize: "13.5px",
    fontWeight: "500",
    color: "#c9d1d9",
    textAlign: "left"
  },
  input: {
    width: "100%",
    padding: "10px 14px",
    backgroundColor: "#e5e9ef",
    color: "#1f2328",
    border: "1px solid #c0c6ce",
    borderRadius: "4px",
    fontSize: "14px",
    fontWeight: "500",
    outline: "none",
    boxSizing: "border-box"
  },
  select: {
    width: "100%",
    padding: "10px 14px",
    backgroundColor: "#e5e9ef",
    color: "#1f2328",
    border: "1px solid #c0c6ce",
    borderRadius: "4px",
    fontSize: "14px",
    fontWeight: "500",
    cursor: "pointer",
    outline: "none",
    boxSizing: "border-box"
  }
};

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <MemeApp />
  </React.StrictMode>
);
